import React from "react";
import MenuSplitApp from "./MenuSplitApp";

function App() {
  return <MenuSplitApp />;
}

export default App;
